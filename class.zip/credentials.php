<?php

$from_name = "Sumedh Suhrid";

$db_name = "email";
$db_user = "root";
$db_password = "";

//Please add a slash after the domain for example=> i.e http://localhost/simple-email/
$base_url = 'http://localhost/simple-email/'; 